#' Order-Preserved Test-Inverse Confidence Set (OPTICS) Method for Mean Change-Point Detection
#'
#' This function implements the OPTICS method for constructing mean change-points in multivariate data.
#' It splits the data into odd and even samples, fits candidate models, and uses a bootstrap-based
#' validation approach to select the optimal model.
#'
#' @param X A numeric matrix of size \eqn{p \times n}, where \eqn{p} is the number of dimensions and \eqn{n} is the number of observations.
#' @param model A numeric vector specifying the candidate numbers of change-points to consider.
#' @param method A character string specifying the change-point detection method. Options are \code{'BinSeg'} (Binary Segmentation) or \code{'SegNeigh'}
#'   (Segment Neighbourhood). Default is \code{'BinSeg'}.
#' @param alpha A numeric value specifying the confidence level for model selection. Must be in the range (0, 1). Default is \code{0.1}.
#' @param B A positive integer specifying the number of bootstrap iterations. Default is \code{200}.
#'
#' @return A list containing:
#' \describe{
#'   \item{\code{A}}{Confidence set.}
#'   \item{\code{model.min}}{The best model based on the minimum error.}
#' }
#'
#' @examples
#' # Simulate data
#' set.seed(123)
#' X <- matrix(rnorm(200), nrow = 2) # Two dimensions, 100 observations
#' model <- c(1, 2, 3)              # Candidate change-point models
#'
#' # Run OPTICS.mean
#' result <- OPTICS.mean(X, model = model, method = 'BinSeg', alpha = 0.1, B = 100)
#' print(result)
#'
#' @export
OPTICS.mean <- function(X, model, method = c('BinSeg', 'SegNeigh'), alpha = 0.1, B = 200) {
  # Input validation
  if (!is.matrix(X)) stop("Input 'X' must be a matrix.")
  if (!is.numeric(model) || any(model <= 0)) stop("Input 'model' must be a numeric vector of positive integers.")
  if (!method %in% c('BinSeg', 'SegNeigh')) stop("Input 'method' must be either 'BinSeg' or 'SegNeigh'.")
  if (!is.numeric(alpha) || alpha <= 0 || alpha >= 1) stop("Input 'alpha' must be a numeric value in (0, 1).")
  if (!is.numeric(B) || B <= 0 || B != as.integer(B)) stop("Input 'B' must be a positive integer.")

  # Extract dimensions
  p <- dim(X)[1]
  n <- dim(X)[2]

  # Ensure even number of columns
  if (n %% 2 != 0) {
    warning("Input matrix has an odd number of columns; the last column will be dropped.")
    n <- n - 1
    X <- X[, 1:n, drop=FALSE]
  }

  # Data splitting
  tt <- 1:n
  index_O <- tt[tt %% 2 == 1]
  index_E <- tt[tt %% 2 == 0]
  O_df <- X[, index_O, drop = FALSE]
  E_df <- X[, index_E, drop = FALSE]

  # Initialize error matrix
  K <- length(model)
  Err_matrix <- matrix(nrow = K, ncol = n)

  # Compute error matrix
  for (i in 1:K) {
    k <- model[i]

    # Fit change-point model on odd samples
    res_fit <- changepoint::cpt.mean(as.numeric(O_df[1, ,drop = FALSE]), penalty = 'None', method = method, Q = k, class = FALSE)
    change_points <- res_fit[-length(res_fit)]
    mean_c <- estimate_mean(O_df, change_points)
    Err_matrix[i, index_E] <- apply(E_df - mean_c, 2, l2)

    # Fit change-point model on even samples
    res_fit <- changepoint::cpt.mean(as.numeric(E_df[1, ,drop = FALSE]), penalty = 'None', method = method, Q = k, class = FALSE)
    change_points <- res_fit[-length(res_fit)]
    mean_c <- estimate_mean(E_df, change_points)
    Err_matrix[i, index_O] <- apply(O_df - mean_c, 2, l2)
  }

  # Validation
  p_c <- numeric(K)
  for (k in 1:K) {
    Res_Error <- matrix(nrow = K - 1, ncol = n)
    res_set <- setdiff(1:K, k)
    for (i in 1:(K - 1)) {
      Res_Error[i, ] <- Err_matrix[k, ] - Err_matrix[res_set[i], ]
    }
    p_c[k] <- Bootstrap_fun(Res_Error = Res_Error, B = B)
  }

  model.min <- which.min(rowMeans(Err_matrix^2))
  return(list(A = model[p_c > alpha], model.min = model[model.min]))
}


#' Multidimensional Mean Change Detection using OPTICS
#'
#' This function performs multidimensional mean change-point detection using the OPTICS framework.
#' The input data is split into odd and even samples, and candidate models are evaluated using
#' a bootstrap procedure for validation.
#'
#' @param X A numeric matrix of size \eqn{p \times n}, where \eqn{p} is the number of dimensions
#'   and \eqn{n} is the number of observations.
#' @param model A numeric vector specifying the candidate numbers of change points to consider.
#' @param alpha A numeric value specifying the confidence level for model selection. Must be in the range
#'   \eqn{(0, 1)}. Default is \code{0.1}.
#' @param B A positive integer specifying the number of bootstrap iterations. Default is \code{200}.
#' @param delta A numeric value specifying the minimum distance between two adjacent change points. Default is \code{20}.
#'
#' @return A list containing:
#' \describe{
#'   \item{\code{A}}{A vector of models that pass the confidence level threshold.}
#'   \item{\code{model.min}}{The best model based on the minimum error.}
#' }
#'
#' @examples
#' # Simulate data
#' set.seed(123)
#' X <- matrix(rnorm(200), nrow = 5) # 5 dimensions, 40 observations
#' model <- c(1, 2, 3)              # Candidate change-point models
#'
#' # Run OPTICS.dmean
#' result <- OPTICS.dmean(X, model = model, alpha = 0.1, B = 200, delta = 20)
#' print(result)
#'
#' @export
OPTICS.dmean <- function(X, model, alpha = 0.1, B = 200, delta = 20) {
  # Input validation
  if (!is.matrix(X)) stop("Input 'X' must be a matrix.")
  if (!is.numeric(model) || any(model <= 0)) stop("Input 'model' must be a numeric vector of positive integers.")
  if (!is.numeric(alpha) || alpha <= 0 || alpha >= 1) stop("Input 'alpha' must be a numeric value in (0, 1).")
  if (!is.numeric(B) || B <= 0 || B != as.integer(B)) stop("Input 'B' must be a positive integer.")
  if (!is.numeric(delta) || delta <= 0) stop("Input 'delta' must be a positive numeric value.")

  # Extract dimensions
  p <- nrow(X)
  n <- ncol(X)

  # Ensure even number of columns
  if (n %% 2 != 0) {
    warning("Input matrix has an odd number of columns; the last column will be dropped.")
    n <- n - 1
    X <- X[, 1:n, drop = FALSE]
  }

  # Data splitting
  tt <- 1:n
  index_O <- tt[tt %% 2 == 1] # Odd indices
  index_E <- tt[tt %% 2 == 0] # Even indices
  O_df <- X[, index_O, drop = FALSE] # Odd sample
  E_df <- X[, index_E, drop = FALSE] # Even sample

  # Initialize error matrix
  K <- length(model)
  Err_matrix <- matrix(nrow = K, ncol = n)

  # Compute error matrix
  for (i in seq_along(model)) {
    k <- model[i]
    #print(i)
    # Fit change-point model on odd samples
    change_points <- network.detection.fun(O_df, num = k, delta = delta)
    mean_c <- estimate_mean(O_df, change_points)
    Err_matrix[i, index_E] <- apply(E_df - mean_c, 2, l2)

    # Fit change-point model on even samples
    change_points <- network.detection.fun(E_df, num = k, delta = delta)
    mean_c <- estimate_mean(E_df, change_points)
    Err_matrix[i, index_O] <- apply(O_df - mean_c, 2, l2)
  }

  # Bootstrap Validation
  p_c <- numeric(K)
  for (k in seq_along(model)) {
    Res_Error <- matrix(nrow = K - 1, ncol = n)
    res_set <- setdiff(seq_along(model), k)
    for (i in seq_along(res_set)) {
      Res_Error[i, ] <- Err_matrix[k, ] - Err_matrix[res_set[i], ]
    }
    p_c[k] <- Bootstrap_fun(Res_Error = Res_Error, B = B)
  }

  # Select the model with the minimum error
  model.min <- which.min(rowMeans(Err_matrix^2))
  return(list(A = model[p_c > alpha], model.min = model[model.min]))
}

#' Estimate Mean Values for Each Segment Based on Change-Points
#'
#' @param X A numeric matrix of size \eqn{p \times n}.
#' @param change_points A numeric vector of change-point locations.
#'
#' @return A matrix of the same dimensions as \code{X} with estimated mean values for each segment.
estimate_mean <- function(X, change_points) {
  if (!is.matrix(X)) stop("Input 'X' must be a matrix.")
  if (!is.numeric(change_points)) stop("Input 'change_points' must be numeric.")

  n <- dim(X)[2]
  p <- dim(X)[1]
  change_points <- c(0, change_points, n)
  mean_c <- matrix(ncol = n, nrow = p)

  for (i in 1:(length(change_points) - 1)) {
    segment_indices <- (change_points[i] + 1):change_points[i + 1]
    segment_data <- X[, segment_indices, drop = FALSE]
    mean_c[, segment_indices] <- matrix(rowMeans(segment_data), nrow = p, ncol = length(segment_indices), byrow = FALSE)
  }

  return(mean_c)
}

#' Compute L2 Norm of a Vector
#'
#' @param x A numeric vector.
#'
#' @return The L2 norm (sum of squared absolute values) of \code{x}.
l2 <- function(x) {
  if (!is.numeric(x)) stop("Input 'x' must be numeric.")
  return(sum(abs(x)^2))
}

#' Bootstrap-Based p-Value Computation
#'
#' @param Res_Error A matrix of residual errors.
#' @param B A positive integer specifying the number of bootstrap iterations (default = 200).
#'
#' @return A numeric p-value.
Bootstrap_fun <- function(Res_Error, B = 200) {
  if (!is.matrix(Res_Error)) stop("Input 'Res_Error' must be a matrix.")
  if (!is.numeric(B) || B <= 0 || B != as.integer(B)) stop("Input 'B' must be a positive integer.")

  n <- dim(Res_Error)[2]
  Sd <- 1 / apply(Res_Error, 1, sd)
  Tt <- (1 / sqrt(n)) * diag(Sd) %*% matrix(rowSums(Res_Error), ncol = 1)
  Tt_max <- max(Tt)

  Tn_c <- numeric(B)
  for (b in 1:B) {
    eta <- rnorm(n)
    Tn <- (1 / sqrt(n)) * diag(Sd) %*% matrix(rowSums((Res_Error - rowMeans(Res_Error)) %*% diag(eta)), ncol = 1)
    Tn_c[b] <- max(Tn)
  }

  return(mean(Tn_c > Tt_max))
}
