#' OPTICS for Covariance Change-Point Detection
#'
#' This function implements the Order-Preserved Test-Inverse Confidence Set (OPTICS) method for detecting
#' change points in covariance structures. The input data is transformed into a lower-triangular covariance
#' matrix representation, and candidate models are validated using a bootstrap procedure.
#'
#' @param X A numeric matrix of size \eqn{p \times n}, where \eqn{p} is the number of dimensions and
#'   \eqn{n} is the number of observations.
#' @param model A numeric vector specifying the candidate numbers of change points to consider.
#' @param alpha A numeric value specifying the confidence level for model selection. Must be in the range
#'   \eqn{(0, 1)}. Default is \code{0.1}.
#' @param B A positive integer specifying the number of bootstrap iterations. Default is \code{200}.
#' @param delta A numeric value specifying the minimum distance between two adjacent change points. Default is \code{20}.
#'
#' @return A list containing:
#' \describe{
#'   \item{\code{A}}{A vector of models that pass the confidence level threshold.}
#'   \item{\code{model.min}}{The best model based on the minimum error.}
#' }
#'
#' @examples
#' \dontrun{
#' # Simulate data
#' set.seed(123)
#' X <- matrix(rnorm(200), nrow = 2) # Two dimensions, 100 observations
#' model <- c(1, 2, 3)              # Candidate change-point models
#'
#' # Run OPTICS.covariance
#' result <- OPTICS.covariance(X, model = model, alpha = 0.1, B = 200)
#' print(result)
#' }
#'
#' @export
OPTICS.covariance <- function(X, model, alpha = 0.1, B = 200, delta=20) {
  .optics_validate_X_model_alpha_B(X, model, alpha, B)
  p <- nrow(X)
  split <- .optics_prepare_odd_even_split(X)
  X <- split$X
  n <- split$n

  # Transform input data into a lower-triangular covariance matrix representation
  inner_X <- matrix(ncol = n, nrow = p * (p - 1) / 2)
  for (i in seq_len(n)) {
    res_x <- X[, i, drop = FALSE]
    res_Sigma <- res_x %*% t(res_x) # Compute covariance matrix for each column
    inner_X[, i] <- as.vector(res_Sigma[lower.tri(res_Sigma)]) # Extract lower triangular part
  }
  X <- inner_X

  split <- .optics_prepare_odd_even_split(X)
  index_O <- split$index_O
  index_E <- split$index_E
  O_df <- split$O_df
  E_df <- split$E_df

  # Initialize error matrix
  K <- length(model)
  Err_matrix <- matrix(nrow = K, ncol = n)

  # Compute the error matrix for each candidate model
  for (i in seq_along(model)) {
    k <- model[i]

    # Fit change-point model on odd samples
    change_points <- covariance.detection.fun(O_df, num = k, delta = delta)
    mean_c <- estimate_mean(O_df, change_points)
    Err_matrix[i, index_E] <- apply(E_df - mean_c, 2, l2)

    # Fit change-point model on even samples
    change_points <- covariance.detection.fun(E_df, num = k, delta = delta)
    mean_c <- estimate_mean(E_df, change_points)
    Err_matrix[i, index_O] <- apply(O_df - mean_c, 2, l2)
  }

  p_c <- .optics_bootstrap_pvals(Err_matrix = Err_matrix, B = B)

  # Select the model with the minimum error
  model.min <- which.min(rowMeans(Err_matrix^2))
  list(A = model[p_c > alpha], model.min = model[model.min])
}




#' Covariance Change-Point Detection using WBS
#'
#' This function detects covariance change points in multivariate data using the Wild Binary Segmentation
#' (WBS) approach. It splits the input data into odd and even indexed columns, generates WBS intervals,
#' and applies covariance-based WBS to detect the change points.
#'
#' @param data_mat A numeric matrix where each column is an observation and rows represent features.
#' @param num An integer specifying the number of change points to detect.
#' @param delta A numeric value specifying the minimum distance between two adjacent change points. Default is \code{20}.
#'
#' @return A numeric vector containing the detected change points, scaled for the original data.
#'
#' @examples
#' \dontrun{
#' # Simulate data
#' set.seed(123)
#' data_mat <- matrix(rnorm(200), nrow = 5) # 5 features, 40 observations
#'
#' # Detect covariance change points
#' result <- covariance.detection.fun(data_mat, num = 2, delta = 20)
#' print(result)
#' }
#'
#' @export
covariance.detection.fun <- function(data_mat, num, delta = 20) {
  # Validate inputs
  if (!is.matrix(data_mat)) stop("Input 'data_mat' must be a matrix.")
  if (!is.numeric(num) || num <= 0 || num != as.integer(num)) stop("Input 'num' must be a positive integer.")
  if (!is.numeric(delta) || delta <= 0) stop("Input 'delta' must be a positive numeric value.")

  # Split the matrix into odd and even indexed columns
  data_mat1 <- data_mat[, seq(1, ncol(data_mat), 2), drop = FALSE] # Odd columns
  data_mat2 <- data_mat[, seq(2, ncol(data_mat), 2), drop = FALSE] # Even columns

  # Generate WBS intervals
  intervals <- changepoints::WBS.intervals(M = 10, lower = 1, upper = ncol(data_mat1))

  # Apply covariance-based WBS detection
  temp <- changepoints::WBSIP.cov(
    data_mat1,
    data_mat2,
    s = 1,
    e = ncol(data_mat1),
    intervals$Alpha,
    intervals$Beta,
    delta = delta
  )
  if (is.null(temp$S) || is.null(temp$Dval) || length(temp$S) == 0 || length(temp$Dval) == 0) {
    return(integer(0))
  }

  # Select and refine change points
  n_avail <- min(num, length(temp$S))
  cpt_init <- sort(temp$S[order(temp$Dval, decreasing = TRUE)[seq_len(n_avail)]]) # Top `num` change points
  cpt_WBS <- 2 * cpt_init # Adjust for original scale (since data was split into odd/even)

  return(cpt_WBS)
}
