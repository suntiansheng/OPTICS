#' Change-Point Detection for m-Dependent Data using OPTICS
#'
#' This function performs change-point detection for m-dependent data using the OPTICS framework.
#' The algorithm iteratively splits the input data based on mod-m indexing, applies change-point detection
#' using Binary Segmentation ('BinSeg') or Segment Neighborhood ('SegNeigh') methods, and combines results
#' using a Cauchy Combination Test (CCT).
#'
#' @param X A numeric matrix of size \eqn{p \times n}, where \eqn{p} is the number of dimensions
#'   and \eqn{n} is the number of observations.
#' @param model A numeric vector specifying the candidate numbers of change points to consider.
#' @param method A character string specifying the segmentation method to use. Must be either
#'   \code{'BinSeg'} or \code{'SegNeigh'}.
#' @param M An integer specifying the dependency modulation (number of mod-m groups).
#' @param alpha A numeric value specifying the confidence level for model selection. Must be in
#'   the range \eqn{(0, 1)}. Default is \code{0.1}.
#' @param B A positive integer specifying the number of bootstrap iterations. Default is \code{200}.
#'
#' @return A list containing:
#' \describe{
#'   \item{\code{A}}{A vector of models that pass the confidence level threshold.}
#' }
#'
#' @examples
#' # Simulate data
#' set.seed(123)
#' X <- matrix(rnorm(200), nrow = 5) # 5 dimensions, 40 observations
#' model <- c(1, 2, 3)              # Candidate change-point models
#'
#' # Run OPTICS.m_dependent
#' result <- OPTICS.m_dependent(X, model = model, method = "BinSeg", M = 2, alpha = 0.1, B = 200)
#' print(result)
#'
#' @export
OPTICS.m_dependent <- function(X, model, method = c('BinSeg', 'SegNeigh'), M, alpha = 0.1, B = 200) {
  # Match the method argument
  method <- match.arg(method)

  # Input validation
  if (!is.matrix(X)) stop("Input 'X' must be a matrix.")
  if (!is.numeric(model) || any(model <= 0)) stop("Input 'model' must be a numeric vector of positive integers.")
  if (!is.numeric(M) || M <= 0 || M != as.integer(M)) stop("Input 'M' must be a positive integer.")
  if (!is.numeric(alpha) || alpha <= 0 || alpha >= 1) stop("Input 'alpha' must be a numeric value in (0, 1).")
  if (!is.numeric(B) || B <= 0 || B != as.integer(B)) stop("Input 'B' must be a positive integer.")

  # Initialize variables
  K <- length(model) # Number of candidate change-point models
  P_m <- matrix(nrow = K, ncol = M) # To store p-values for each model and mod-m group
  XX <- X                          # Original data matrix
  n <- ncol(X)                     # Number of observations
  tt <- 1:n                        # Index vector

  # Iterate over mod-m groups
  for (m in 0:(M - 1)) {
    # Subset data based on mod-m indexing
    X <- XX[, tt %% M == m, drop = FALSE]

    # Extract dimensions
    p1 <- nrow(X)
    n1 <- ncol(X)

    # Ensure even number of columns
    if (n1 %% 2 != 0) {
      warning("Input matrix has an odd number of columns; the last column will be dropped for mod-m group.")
      n1 <- n1 - 1
      X <- X[, 1:n1, drop = FALSE]
    }

    # Data splitting
    tt <- 1:n1
    index_O <- tt[tt %% 2 == 1] # Odd indices
    index_E <- tt[tt %% 2 == 0] # Even indices
    O_df <- X[, index_O, drop = FALSE] # Odd sample
    E_df <- X[, index_E, drop = FALSE] # Even sample

    # Initialize error matrix
    Err_matrix <- matrix(nrow = K, ncol = n1)

    # Compute error matrix for each candidate model
    for (i in seq_along(model)) {
      k <- model[i]

      # Fit change-point model on odd samples
      res_fit <- changepoint::cpt.mean(
        as.numeric(O_df[1, , drop = FALSE]),
        penalty = 'None',
        method = method,
        Q = k,
        class = FALSE
      )
      change_points <- res_fit[-length(res_fit)]
      mean_c <- estimate_mean(O_df, change_points)
      Err_matrix[i, index_E] <- apply(E_df - mean_c, 2, l2)

      # Fit change-point model on even samples
      res_fit <- changepoint::cpt.mean(
        as.numeric(E_df[1, , drop = FALSE]),
        penalty = 'None',
        method = method,
        Q = k,
        class = FALSE
      )
      change_points <- res_fit[-length(res_fit)]
      mean_c <- estimate_mean(E_df, change_points)
      Err_matrix[i, index_O] <- apply(O_df - mean_c, 2, l2)
    }

    # Compute p-values using bootstrap
    for (k in seq_along(model)) {
      Res_Error <- matrix(nrow = K - 1, ncol = n1)
      res_set <- setdiff(seq_along(model), k)
      for (i in seq_along(res_set)) {
        Res_Error[i, ] <- Err_matrix[k, ] - Err_matrix[res_set[i], ]
      }
      P_m[k, m + 1] <- Bootstrap_fun(Res_Error = Res_Error, B = B)
    }
  }

  # Aggregate p-values using the Cauchy Combination Test (CCT)
  p_c <- apply(P_m, 1, CCT)

  # Return models passing the significance threshold
  return(list(A = model[p_c > alpha]))
}

#' Cauchy Combination Test (CCT)
#'
#' Combines p-values using the Cauchy Combination Test.
#'
#' @param pvals A numeric vector of p-values.
#' @param weights An optional numeric vector of weights for the p-values. Default is equal weights.
#' @return A combined p-value.
CCT <- function(pvals, weights = NULL) {
  # Input validation
  if (sum(is.na(pvals)) > 0) stop("Cannot have NAs in the p-values!")
  if ((sum(pvals < 0) + sum(pvals > 1)) > 0) stop("All p-values must be between 0 and 1!")
  if (any(pvals == 0)) return(0) # If any p-value is 0, return 0
  if (any(pvals == 1)) return(1) # If any p-value is 1, return 1

  # Standardize weights
  if (is.null(weights)) {
    weights <- rep(1 / length(pvals), length(pvals))
  } else {
    if (length(weights) != length(pvals)) stop("Weights must match the length of p-values!")
    if (any(weights < 0)) stop("Weights must be non-negative!")
    weights <- weights / sum(weights)
  }

  # Compute CCT statistic
  cct_stat <- sum(weights * tan((0.5 - pvals) * pi))
  if (cct_stat > 1e+15) {
    return((1 / cct_stat) / pi)
  } else {
    return(1 - pcauchy(cct_stat))
  }
}
