#' OPTICS for Linear Regression Coefficient Structural Breaks
#'
#' This function applies OPTICS to linear regression structural-break problems
#' by transforming \eqn{(X, y)} into a multivariate mean-change sequence and
#' delegating model fitting/validation to \code{OPTICS.dmean}.
#'
#' @param X A numeric design matrix of size \eqn{n \times d}, where \eqn{n} is
#'   the number of observations and \eqn{d} is the number of covariates.
#' @param y A numeric response vector of length \eqn{n}, or an \eqn{n \times 1}
#'   numeric matrix.
#' @param model A numeric vector specifying the candidate numbers of
#'   change-points to consider.
#' @param method A character string specifying the change-point detection
#'   method. Options are \code{'BinSeg'} and \code{'SegNeigh'}. Default is
#'   \code{'BinSeg'}.
#' @param alpha A numeric value in \eqn{(0, 1)} specifying the significance
#'   level used in OPTICS validation. Default is \code{0.1}.
#' @param B A positive integer specifying the number of bootstrap iterations.
#'   Default is \code{200}.
#' @param delta A positive numeric value specifying the minimum distance between
#'   adjacent change-points. Default is \code{20}.
#'
#' @return A list with components:
#' \describe{
#'   \item{\code{A}}{Estimated confidence set for the number of change-points.}
#'   \item{\code{model.min}}{Point estimate selected by minimum validation error.}
#' }
#'
#' @examples
#' \dontrun{
#' set.seed(123)
#' n <- 200
#' d <- 5
#' X <- matrix(rnorm(n * d), nrow = n, ncol = d)
#' beta <- c(rep(0.5, d), rep(-0.5, d))
#' y <- c(X[1:100, ] %*% beta[1:d], X[101:200, ] %*% beta[(d + 1):(2 * d)]) + rnorm(n)
#' out <- OPTICS.linear(X, y, model = 1:5, method = "BinSeg")
#' print(out)
#' }
#'
#' @export
OPTICS.linear <- function(X, y, model, method = c("BinSeg", "SegNeigh"), alpha = 0.1, B = 200, delta = 20) {
  method <- match.arg(method)
  if (!is.matrix(X)) stop("Input 'X' must be a matrix.")
  if (!is.numeric(X)) stop("Input 'X' must be numeric.")

  if (is.matrix(y)) {
    if (ncol(y) != 1) stop("If 'y' is a matrix, it must have exactly one column.")
    y <- as.numeric(y[, 1])
  }
  if (!is.numeric(y)) stop("Input 'y' must be numeric.")
  if (nrow(X) != length(y)) stop("Number of rows of 'X' must match length of 'y'.")

  # Transform linear model into multivariate mean-change sequence:
  # Z_i = x_i * y_i, represented as a d x n matrix.
  Z <- t(X * y)

  OPTICS.dmean(
    X = Z,
    model = model,
    method = method,
    alpha = alpha,
    B = B,
    delta = delta
  )
}
