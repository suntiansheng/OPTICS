#' OPTICS for Covariance Change-Point Detection
#'
#' This function implements the Order-Preserved Test-Inverse Confidence Set (OPTICS) method for detecting
#' change points in covariance structures. The input data is transformed into a lower-triangular covariance
#' matrix representation, and candidate models are validated using a bootstrap procedure.
#'
#' @param X A numeric matrix of size \eqn{p \times n}, where \eqn{p} is the number of dimensions and
#'   \eqn{n} is the number of observations.
#' @param model A numeric vector specifying the candidate numbers of change points to consider.
#' @param alpha A numeric value specifying the confidence level for model selection. Must be in the range
#'   \eqn{(0, 1)}. Default is \code{0.1}.
#' @param B A positive integer specifying the number of bootstrap iterations. Default is \code{200}.
#'
#' @return A list containing:
#' \describe{
#'   \item{\code{A}}{A vector of models that pass the confidence level threshold.}
#'   \item{\code{model.min}}{The best model based on the minimum error.}
#' }
#'
#' @examples
#' # Simulate data
#' set.seed(123)
#' X <- matrix(rnorm(200), nrow = 2) # Two dimensions, 100 observations
#' model <- c(1, 2, 3)              # Candidate change-point models
#'
#' # Run OPTICS.covariance
#' result <- OPTICS.covariance(X, model = model, alpha = 0.1, B = 200)
#' print(result)
#'
#' @export
OPTICS.covariance <- function(X, model, alpha = 0.1, B = 200, delta=20) {
  # Validate inputs
  if (!is.matrix(X)) stop("Input 'X' must be a matrix.")
  if (!is.numeric(model) || any(model <= 0)) stop("Input 'model' must be a numeric vector of positive integers.")
  if (!is.numeric(alpha) || alpha <= 0 || alpha >= 1) stop("Input 'alpha' must be a numeric value in (0, 1).")
  if (!is.numeric(B) || B <= 0 || B != as.integer(B)) stop("Input 'B' must be a positive integer.")

  # Extract dimensions
  p <- nrow(X)
  n <- ncol(X)

  # Ensure even number of columns
  if (n %% 2 != 0) {
    warning("Input matrix has an odd number of columns; the last column will be dropped.")
    n <- n - 1
    X <- X[, 1:n]
  }

  # Transform input data into a lower-triangular covariance matrix representation
  inner_X <- matrix(ncol = n, nrow = p * (p - 1) / 2)
  for (i in 1:n) {
    res_x <- X[, i, drop = FALSE]
    res_Sigma <- res_x %*% t(res_x) # Compute covariance matrix for each column
    inner_X[, i] <- as.vector(res_Sigma[lower.tri(res_Sigma)]) # Extract lower triangular part
  }
  X <- inner_X

  # Data splitting into odd and even samples
  tt <- 1:n
  index_O <- tt[tt %% 2 == 1] # Odd indices
  index_E <- tt[tt %% 2 == 0] # Even indices
  O_df <- X[, index_O, drop = FALSE] # Odd sample
  E_df <- X[, index_E, drop = FALSE] # Even sample

  # Initialize error matrix
  K <- length(model)
  Err_matrix <- matrix(nrow = K, ncol = n)

  # Compute the error matrix for each candidate model
  for (i in seq_along(model)) {
    k <- model[i]

    # Fit change-point model on odd samples
    res_fit <- network.detection.fun(O_df, num = k, delta=delta)
    change_points <- res_fit[-length(res_fit)]
    mean_c <- estimate_mean(O_df, change_points)
    Err_matrix[i, index_E] <- apply(E_df - mean_c, 2, l2)

    # Fit change-point model on even samples
    res_fit <- network.detection.fun(E_df, num = k, delta=delta)
    change_points <- res_fit[-length(res_fit)]
    mean_c <- estimate_mean(E_df, change_points)
    Err_matrix[i, index_O] <- apply(O_df - mean_c, 2, l2)
  }

  # Bootstrap Validation
  p_c <- numeric(K)
  for (k in seq_along(model)) {
    # Initialize residual error matrix
    Res_Error <- matrix(nrow = K - 1, ncol = n)
    res_set <- setdiff(seq_along(model), k)

    for (i in seq_along(res_set)) {
      Res_Error[i, ] <- Err_matrix[k, ] - Err_matrix[res_set[i], ]
    }

    # Perform bootstrap
    p_c[k] <- Bootstrap_fun(Res_Error = Res_Error, B = B)
  }

  # Select the model with the minimum error
  model.min <- which.min(rowMeans(Err_matrix^2))
  return(list(A = model[p_c > alpha], model.min = model[model.min]))
}




#' Covariance Change-Point Detection using WBS
#'
#' This function detects covariance change points in multivariate data using the Wild Binary Segmentation
#' (WBS) approach. It splits the input data into odd and even indexed columns, generates WBS intervals,
#' and applies covariance-based WBS to detect the change points.
#'
#' @param data_mat A numeric matrix where each column is an observation and rows represent features.
#' @param num An integer specifying the number of change points to detect.
#' @param delta A numeric value specifying the minimum distance between two adjacent change points. Default is \code{20}.
#'
#' @return A numeric vector containing the detected change points, scaled for the original data.
#'
#' @examples
#' # Simulate data
#' set.seed(123)
#' data_mat <- matrix(rnorm(200), nrow = 5) # 5 features, 40 observations
#'
#' # Detect covariance change points
#' result <- covariance.detection.fun(data_mat, num = 2, delta = 20)
#' print(result)
#'
#' @export
covariance.detection.fun <- function(data_mat, num, delta = 20) {
  # Validate inputs
  if (!is.matrix(data_mat)) stop("Input 'data_mat' must be a matrix.")
  if (!is.numeric(num) || num <= 0 || num != as.integer(num)) stop("Input 'num' must be a positive integer.")
  if (!is.numeric(delta) || delta <= 0) stop("Input 'delta' must be a positive numeric value.")

  # Split the matrix into odd and even indexed columns
  data_mat1 <- data_mat[, seq(1, ncol(data_mat), 2), drop = FALSE] # Odd columns
  data_mat2 <- data_mat[, seq(2, ncol(data_mat), 2), drop = FALSE] # Even columns

  # Generate WBS intervals
  intervals <- changepoints::WBS.intervals(M = 10, lower = 1, upper = ncol(data_mat1))

  # Apply covariance-based WBS detection
  temp <- WBSIP.cov(
    data_mat1,
    data_mat2,
    s = 1,
    e = ncol(data_mat1),
    intervals$Alpha,
    intervals$Beta,
    delta = delta
  )

  # Select and refine change points
  cpt_init <- sort(temp$S[order(temp$Dval, decreasing = TRUE)[1:num]]) # Top `num` change points
  cpt_WBS <- 2 * cpt_init # Adjust for original scale (since data was split into odd/even)

  return(cpt_WBS)
}



