test_that("R_MOPS returns changepoints on original odd index scale", {
  skip_if_not_installed("changepoint")
  skip_if_not_installed("knockoff")

  set.seed(1)
  n <- 200
  x <- c(rnorm(100, 0, 1), rnorm(100, 2, 1))
  X <- matrix(x, nrow = 1)
  cp <- OPTICS::R_MOPS(X, fdr = 0.2, method = "BinSeg")

  if (length(cp) > 0) {
    expect_true(all(cp %% 2 == 1))
    expect_true(all(cp >= 1 & cp <= n))
  } else {
    succeed()
  }
})
