#' OPTICS for Network Change-Point Detection
#'
#' This function implements the Order-Preserved Test-Inverse Confidence Set (OPTICS) method
#' for detecting network change points in multivariate data. It uses cross-validation
#' based on odd/even sample splitting, evaluates candidate models, and uses bootstrap-based
#' validation to select the optimal number of change points.
#'
#' @param X A numeric matrix of size \eqn{p \times n}, where \eqn{p} is the number of dimensions and \eqn{n} is the number of observations.
#' @param model A numeric vector specifying the candidate numbers of change points to consider.
#' @param alpha A numeric value specifying the confidence level for model selection. Must be in the range \eqn{(0, 1)}. Default is \code{0.1}.
#' @param B A positive integer specifying the number of bootstrap iterations. Default is \code{200}.
#' @param delta A numeric value specifying the minimum distance between two adjacent change points. Default is \code{20}.
#'
#' @return A list containing:
#' \describe{
#'   \item{\code{A}}{A vector of models that pass the confidence level threshold.}
#'   \item{\code{model.min}}{The best model based on the minimum error.}
#' }
#'
#' @examples
#' \dontrun{
#' # Simulate data
#' set.seed(123)
#' X <- matrix(rnorm(200), nrow = 2) # Two dimensions, 100 observations
#' model <- c(1, 2, 3)              # Candidate change-point models
#'
#' # Run OPTICS.network
#' result <- OPTICS.network(X, model = model, alpha = 0.1, B = 200)
#' print(result)
#' }
#'
#' @export
OPTICS.network <- function(X, model, alpha = 0.1, B = 200, delta = 20) {
  .optics_validate_X_model_alpha_B(X, model, alpha, B)
  split <- .optics_prepare_odd_even_split(X)
  n <- split$n
  index_O <- split$index_O
  index_E <- split$index_E
  O_df <- split$O_df
  E_df <- split$E_df

  # Initialize error matrix
  K <- length(model)
  Err_matrix <- matrix(nrow = K, ncol = n)

  # Compute the error matrix for each candidate model
  for (i in seq_along(model)) {
    k <- model[i]

    # Fit change-point model on odd samples
    change_points <- network.detection.fun(O_df, num = k, delta = delta)
    mean_c <- estimate_mean(O_df, change_points)
    Err_matrix[i, index_E] <- apply(E_df - mean_c, 2, l2)

    # Fit change-point model on even samples
    change_points <- network.detection.fun(E_df, num = k, delta = delta)
    mean_c <- estimate_mean(E_df, change_points)
    Err_matrix[i, index_O] <- apply(O_df - mean_c, 2, l2)
  }

  p_c <- .optics_bootstrap_pvals(Err_matrix = Err_matrix, B = B)

  # Select the model with the minimum error
  model.min <- which.min(rowMeans(Err_matrix^2))
  list(A = model[p_c > alpha], model.min = model[model.min])
}

#' Network Change-Point Detection using WBS
#'
#' This function detects change points in network data using the WBS (Wild Binary Segmentation) method.
#'
#' @param data_mat A numeric matrix of network data to analyze.
#' @param num An integer specifying the number of change points to detect.
#' @param delta A numeric value specifying the minimum distance between two adjacent change points. Default is \code{20}.
#'
#' @return A numeric vector of detected change points.
#' @export
network.detection.fun <- function(data_mat, num, delta) {
  # Validate inputs
  if (!is.matrix(data_mat)) stop("Input 'data_mat' must be a matrix.")
  if (!is.numeric(num) || num <= 0) stop("Input 'num' must be a positive integer.")
  if (!is.numeric(delta) || delta <= 0) stop("Input 'delta' must be a positive numeric value.")

  # Split the matrix into odd and even columns
  data_mat1 <- data_mat[, seq(1, ncol(data_mat), 2), drop = FALSE]
  data_mat2 <- data_mat[, seq(2, ncol(data_mat), 2), drop = FALSE]

  # Generate WBS intervals
  M <- 10
  intervals <- changepoints::WBS.intervals(M = M, lower = 1, upper = ncol(data_mat1))

  # Apply network-based WBS detection
  temp <- changepoints::WBS.network(
    data_mat1, data_mat2, 1, ncol(data_mat1),
    intervals$Alpha, intervals$Beta, delta = delta
  )
  if (is.null(temp$S) || is.null(temp$Dval) || length(temp$S) == 0 || length(temp$Dval) == 0) {
    return(integer(0))
  }

  # Select and refine change points
  n_avail <- min(num, length(temp$S))
  cpt_init <- sort(temp$S[order(temp$Dval, decreasing = TRUE)[seq_len(n_avail)]])
  cpt_WBS <- 2 * cpt_init # Adjust for original scale
  return(cpt_WBS)
}
