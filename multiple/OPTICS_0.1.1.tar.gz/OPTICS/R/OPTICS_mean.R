#' Order-Preserved Test-Inverse Confidence Set (OPTICS) Method for Mean Change-Point Detection
#'
#' This function implements the OPTICS method for constructing mean change-points in multivariate data.
#' It splits the data into odd and even samples, fits candidate models, and uses a bootstrap-based
#' validation approach to select the optimal model.
#'
#' @param X A numeric matrix of size \eqn{p \times n}, where \eqn{p} is the number of dimensions and \eqn{n} is the number of observations.
#' @param model A numeric vector specifying the candidate numbers of change-points to consider.
#' @param method A character string specifying the change-point detection method. Options are \code{'BinSeg'} (Binary Segmentation) or \code{'SegNeigh'}
#'   (Segment Neighbourhood). Default is \code{'BinSeg'}.
#' @param alpha A numeric value specifying the confidence level for model selection. Must be in the range (0, 1). Default is \code{0.1}.
#' @param B A positive integer specifying the number of bootstrap iterations. Default is \code{200}.
#'
#' @return A list containing:
#' \describe{
#'   \item{\code{A}}{Confidence set.}
#'   \item{\code{model.min}}{The best model based on the minimum error.}
#' }
#'
#' @examples
#' # Simulate data
#' set.seed(123)
#' X <- matrix(rnorm(200), nrow = 2) # Two dimensions, 100 observations
#' model <- c(1, 2, 3)              # Candidate change-point models
#'
#' # Run OPTICS.mean
#' result <- OPTICS.mean(X, model = model, method = 'BinSeg', alpha = 0.1, B = 100)
#' print(result)
#'
#' @export
.optics_validate_X_model_alpha_B <- function(X, model, alpha, B) {
  if (!is.matrix(X)) stop("Input 'X' must be a matrix.")
  if (!is.numeric(model) || any(model <= 0)) stop("Input 'model' must be a numeric vector of positive integers.")
  if (!is.numeric(alpha) || alpha <= 0 || alpha >= 1) stop("Input 'alpha' must be a numeric value in (0, 1).")
  if (!is.numeric(B) || B <= 0 || B != as.integer(B)) stop("Input 'B' must be a positive integer.")
}

.optics_prepare_odd_even_split <- function(X) {
  n <- ncol(X)
  if (n %% 2 != 0) {
    warning("Input matrix has an odd number of columns; the last column will be dropped.")
    n <- n - 1
    X <- X[, seq_len(n), drop = FALSE]
  }

  idx <- seq_len(n)
  index_O <- idx[idx %% 2 == 1]
  index_E <- idx[idx %% 2 == 0]
  list(
    X = X,
    n = n,
    index_O = index_O,
    index_E = index_E,
    O_df = X[, index_O, drop = FALSE],
    E_df = X[, index_E, drop = FALSE]
  )
}

.optics_bootstrap_pvals <- function(Err_matrix, B) {
  K <- nrow(Err_matrix)
  n <- ncol(Err_matrix)
  p_c <- numeric(K)
  for (k in seq_len(K)) {
    Res_Error <- matrix(nrow = K - 1, ncol = n)
    res_set <- setdiff(seq_len(K), k)
    for (i in seq_along(res_set)) {
      Res_Error[i, ] <- Err_matrix[k, ] - Err_matrix[res_set[i], ]
    }
    p_c[k] <- Bootstrap_fun(Res_Error = Res_Error, B = B)
  }
  p_c
}

OPTICS.mean <- function(X, model, method = c('BinSeg', 'SegNeigh'), alpha = 0.1, B = 200) {
  method <- match.arg(method)
  .optics_validate_X_model_alpha_B(X, model, alpha, B)
  split <- .optics_prepare_odd_even_split(X)
  n <- split$n
  index_O <- split$index_O
  index_E <- split$index_E
  O_df <- split$O_df
  E_df <- split$E_df

  # Initialize error matrix
  K <- length(model)
  Err_matrix <- matrix(nrow = K, ncol = n)

  # Compute error matrix
  for (i in seq_len(K)) {
    k <- model[i]

    # Fit change-point model on odd samples
    res_fit <- changepoint::cpt.mean(as.numeric(O_df[1, ,drop = FALSE]), penalty = 'None', method = method, Q = k, class = FALSE)
    change_points <- res_fit[-length(res_fit)]
    mean_c <- estimate_mean(O_df, change_points)
    Err_matrix[i, index_E] <- apply(E_df - mean_c, 2, l2)

    # Fit change-point model on even samples
    res_fit <- changepoint::cpt.mean(as.numeric(E_df[1, ,drop = FALSE]), penalty = 'None', method = method, Q = k, class = FALSE)
    change_points <- res_fit[-length(res_fit)]
    mean_c <- estimate_mean(E_df, change_points)
    Err_matrix[i, index_O] <- apply(O_df - mean_c, 2, l2)
  }

  p_c <- .optics_bootstrap_pvals(Err_matrix = Err_matrix, B = B)

  model.min <- which.min(rowMeans(Err_matrix^2))
  list(A = model[p_c > alpha], model.min = model[model.min])
}


#' Multidimensional Mean Change Detection using OPTICS
#'
#' This function performs multidimensional mean change-point detection using the OPTICS framework.
#' The input data is split into odd and even samples, and candidate models are evaluated using
#' a bootstrap procedure for validation.
#'
#' @param X A numeric matrix of size \eqn{p \times n}, where \eqn{p} is the number of dimensions
#'   and \eqn{n} is the number of observations.
#' @param model A numeric vector specifying the candidate numbers of change points to consider.
#' @param method A character string specifying the change-point detection method. Options are \code{'BinSeg'}
#'   or \code{'SegNeigh'}. Default is \code{'BinSeg'}.
#' @param alpha A numeric value specifying the confidence level for model selection. Must be in the range
#'   \eqn{(0, 1)}. Default is \code{0.1}.
#' @param B A positive integer specifying the number of bootstrap iterations. Default is \code{200}.
#' @param delta A numeric value specifying the minimum distance between two adjacent change points. Default is \code{20}.
#'
#' @return A list containing:
#' \describe{
#'   \item{\code{A}}{A vector of models that pass the confidence level threshold.}
#'   \item{\code{model.min}}{The best model based on the minimum error.}
#' }
#'
#' @examples
#' \dontrun{
#' # Simulate data
#' set.seed(123)
#' X <- matrix(rnorm(200), nrow = 5) # 5 dimensions, 40 observations
#' model <- c(1, 2, 3)              # Candidate change-point models
#'
#' # Run OPTICS.dmean
#' result <- OPTICS.dmean(X, model = model, alpha = 0.1, B = 200, delta = 20)
#' print(result)
#' }
#'
#' @export
OPTICS.dmean <- function(X, model, method = c('BinSeg', 'SegNeigh'), alpha = 0.1, B = 200, delta = 20) {
  method <- match.arg(method)
  .optics_validate_X_model_alpha_B(X, model, alpha, B)
  if (!is.numeric(delta) || delta <= 0) stop("Input 'delta' must be a positive numeric value.")

  split <- .optics_prepare_odd_even_split(X)
  n <- split$n
  index_O <- split$index_O
  index_E <- split$index_E
  O_df <- split$O_df
  E_df <- split$E_df

  # Initialize error matrix
  K <- length(model)
  Err_matrix <- matrix(nrow = K, ncol = n)

  # Compute error matrix
  for (i in seq_along(model)) {
    k <- model[i]
    #print(i)
    # Fit change-point model on odd samples
    change_points <- dmean.detection.fun(O_df, num = k, method = method, delta = delta)
    mean_c <- estimate_mean(O_df, change_points)
    Err_matrix[i, index_E] <- apply(E_df - mean_c, 2, l2)

    # Fit change-point model on even samples
    change_points <- dmean.detection.fun(E_df, num = k, method = method, delta = delta)
    mean_c <- estimate_mean(E_df, change_points)
    Err_matrix[i, index_O] <- apply(O_df - mean_c, 2, l2)
  }

  p_c <- .optics_bootstrap_pvals(Err_matrix = Err_matrix, B = B)

  # Select the model with the minimum error
  model.min <- which.min(rowMeans(Err_matrix^2))
  list(A = model[p_c > alpha], model.min = model[model.min])
}

#' Estimate Mean Values for Each Segment Based on Change-Points
#'
#' @param X A numeric matrix of size \eqn{p \times n}.
#' @param change_points A numeric vector of change-point locations.
#'
#' @return A matrix of the same dimensions as \code{X} with estimated mean values for each segment.
estimate_mean <- function(X, change_points) {
  if (!is.matrix(X)) stop("Input 'X' must be a matrix.")
  if (!is.numeric(change_points)) stop("Input 'change_points' must be numeric.")

  n <- dim(X)[2]
  p <- dim(X)[1]
  change_points <- c(0, change_points, n)
  mean_c <- matrix(ncol = n, nrow = p)

  for (i in 1:(length(change_points) - 1)) {
    segment_indices <- (change_points[i] + 1):change_points[i + 1]
    segment_data <- X[, segment_indices, drop = FALSE]
    mean_c[, segment_indices] <- matrix(rowMeans(segment_data), nrow = p, ncol = length(segment_indices), byrow = FALSE)
  }

  return(mean_c)
}

#' Compute L2 Norm of a Vector
#'
#' @param x A numeric vector.
#'
#' @return The L2 norm (sum of squared absolute values) of \code{x}.
l2 <- function(x) {
  if (!is.numeric(x)) stop("Input 'x' must be numeric.")
  return(sum(abs(x)^2))
}

#' Bootstrap-Based p-Value Computation
#'
#' @param Res_Error A matrix of residual errors.
#' @param B A positive integer specifying the number of bootstrap iterations (default = 200).
#'
#' @return A numeric p-value.
Bootstrap_fun <- function(Res_Error, B = 200) {
  if (!is.matrix(Res_Error)) stop("Input 'Res_Error' must be a matrix.")
  if (!is.numeric(B) || B <= 0 || B != as.integer(B)) stop("Input 'B' must be a positive integer.")

  n <- dim(Res_Error)[2]
  row_sd <- apply(Res_Error, 1, stats::sd)
  valid_rows <- which(!is.na(row_sd) & row_sd > 0)
  if (length(valid_rows) == 0) return(1)

  Res_Error <- Res_Error[valid_rows, , drop = FALSE]
  row_sd <- row_sd[valid_rows]
  Sd <- 1 / row_sd
  Tt <- (1 / sqrt(n)) * diag(Sd) %*% matrix(rowSums(Res_Error), ncol = 1)
  Tt_max <- max(Tt)

  Tn_c <- numeric(B)
  for (b in 1:B) {
    eta <- stats::rnorm(n)
    Tn <- (1 / sqrt(n)) * diag(Sd) %*% matrix(rowSums((Res_Error - rowMeans(Res_Error)) %*% diag(eta)), ncol = 1)
    Tn_c[b] <- max(Tn)
  }

  return(mean(Tn_c > Tt_max))
}

#' Detection helper for multivariate mean-change models.
dmean.detection.fun <- function(data_mat, num, method = c("BinSeg", "SegNeigh"), delta = 20) {
  method <- match.arg(method)
  if (method == "BinSeg") {
    return(dmean.bs.fun(data_mat = data_mat, num = num, delta = delta))
  }
  dmean.sn.fun(data_mat = data_mat, num = num, delta = delta)
}

# Multivariate BS using L2 CUSUM score.
dmean.bs.fun <- function(data_mat, num, delta = 20) {
  if (!is.matrix(data_mat)) stop("Input 'data_mat' must be a matrix.")
  if (!is.numeric(num) || num <= 0 || num != as.integer(num)) stop("Input 'num' must be a positive integer.")
  if (!is.numeric(delta) || delta <= 0) stop("Input 'delta' must be a positive numeric value.")

  n <- ncol(data_mat)
  if (n < 2 * delta + 1) return(integer(0))

  cum_x <- cbind(0, t(apply(data_mat, 1, cumsum)))

  best_split <- function(s, e) {
    if ((e - s + 1) < 2 * delta + 1) return(list(cp = NA_integer_, score = -Inf))
    cand_t <- (s + delta - 1):(e - delta)
    best_t <- NA_integer_
    best_score <- -Inf
    for (t in cand_t) {
      l <- t - s + 1
      r <- e - t
      sum_l <- cum_x[, t + 1] - cum_x[, s]
      sum_r <- cum_x[, e + 1] - cum_x[, t + 1]
      diff_mean <- sum_l / l - sum_r / r
      score <- sqrt((l * r) / (l + r)) * sqrt(sum(diff_mean^2))
      if (score > best_score) {
        best_score <- score
        best_t <- t
      }
    }
    list(cp = best_t, score = best_score)
  }

  seg_starts <- 1L
  seg_ends <- n
  cps <- integer(0)

  for (k in seq_len(num)) {
    best_seg_idx <- NA_integer_
    best_seg_cp <- NA_integer_
    best_seg_score <- -Inf

    for (j in seq_along(seg_starts)) {
      res <- best_split(seg_starts[j], seg_ends[j])
      if (is.finite(res$score) && res$score > best_seg_score) {
        best_seg_score <- res$score
        best_seg_cp <- res$cp
        best_seg_idx <- j
      }
    }

    if (!is.finite(best_seg_score) || is.na(best_seg_cp)) break

    s <- seg_starts[best_seg_idx]
    e <- seg_ends[best_seg_idx]
    left_s <- s
    left_e <- best_seg_cp
    right_s <- best_seg_cp + 1
    right_e <- e

    seg_starts <- seg_starts[-best_seg_idx]
    seg_ends <- seg_ends[-best_seg_idx]

    seg_starts <- c(seg_starts, left_s, right_s)
    seg_ends <- c(seg_ends, left_e, right_e)
    cps <- c(cps, best_seg_cp)
  }

  sort(unique(cps))
}

# Multivariate SN via dynamic programming on segment SSE.
dmean.sn.fun <- function(data_mat, num, delta = 20) {
  if (!is.matrix(data_mat)) stop("Input 'data_mat' must be a matrix.")
  if (!is.numeric(num) || num <= 0 || num != as.integer(num)) stop("Input 'num' must be a positive integer.")
  if (!is.numeric(delta) || delta <= 0) stop("Input 'delta' must be a positive numeric value.")

  p <- nrow(data_mat)
  n <- ncol(data_mat)
  k_seg <- num + 1L
  if (n < k_seg * delta) return(integer(0))

  cum_x <- cbind(0, t(apply(data_mat, 1, cumsum)))
  x_norm2 <- colSums(data_mat^2)
  cum_x2 <- c(0, cumsum(x_norm2))

  segment_sse <- function(s, e) {
    m <- e - s + 1
    sum_x <- cum_x[, e + 1] - cum_x[, s]
    sum_sq <- cum_x2[e + 1] - cum_x2[s]
    sum_sq - sum(sum_x^2) / m
  }

  dp <- matrix(Inf, nrow = k_seg, ncol = n)
  back <- matrix(NA_integer_, nrow = k_seg, ncol = n)

  for (j in delta:n) {
    dp[1, j] <- segment_sse(1, j)
  }

  if (k_seg >= 2) {
    for (k in 2:k_seg) {
      j_min <- k * delta
      for (j in j_min:n) {
        m_min <- (k - 1) * delta
        m_max <- j - delta
        if (m_min > m_max) next
        best_val <- Inf
        best_m <- NA_integer_
        for (m in m_min:m_max) {
          val <- dp[k - 1, m] + segment_sse(m + 1, j)
          if (val < best_val) {
            best_val <- val
            best_m <- m
          }
        }
        dp[k, j] <- best_val
        back[k, j] <- best_m
      }
    }
  }

  if (!is.finite(dp[k_seg, n])) return(integer(0))

  cps <- integer(num)
  j <- n
  for (k in k_seg:2) {
    m <- back[k, j]
    if (is.na(m)) return(integer(0))
    cps[k - 1] <- m
    j <- m
  }

  sort(unique(cps))
}
