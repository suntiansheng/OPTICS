library(testthat)
library(OPTICS)

test_check("OPTICS")
