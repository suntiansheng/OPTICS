test_that("OPTICS.ms returns expected structure", {
  set.seed(1)
  X <- matrix(rnorm(6 * 120), nrow = 6)
  model <- c(1, 2, 3)

  out <- OPTICS.ms(
    X = X,
    model = model,
    engine = "dmean",
    method = "BinSeg",
    alpha = 0.1,
    B = 20,
    delta = 10,
    L = 3
  )

  expect_true(is.list(out))
  expect_true(all(c("A_MS", "pvals_split", "pvals_combined", "weights", "model.min_split") %in% names(out)))
  expect_equal(dim(out$pvals_split), c(length(model), 3))
  expect_true(all(out$A_MS %in% model))
  expect_equal(length(out$pvals_combined), length(model))
  expect_equal(length(out$weights), 3)
})

test_that("OPTICS.ms handles non-divisible length with trim", {
  set.seed(2)
  X <- matrix(rnorm(4 * 101), nrow = 4)
  model <- c(1, 2)

  expect_error(
    OPTICS.ms(X, model, L = 3, trim_incomplete = FALSE, B = 10, delta = 8),
    "divisible"
  )
  expect_no_error(
    OPTICS.ms(X, model, L = 3, trim_incomplete = TRUE, B = 10, delta = 8)
  )
})
