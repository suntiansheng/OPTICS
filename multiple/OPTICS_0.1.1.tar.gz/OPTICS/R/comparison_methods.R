#' Compute Bandwidth Intervals for Change Points
#'
#' This function calculates bandwidth intervals around change points. If the bandwidth `h` is not specified,
#' the maximum possible bandwidth is used. The intervals are adjusted to ensure they do not overlap excessively.
#'
#' @param change_points A numeric vector of change-point locations.
#' @param n The number of observations in the dataset.
#' @param h An optional numeric value specifying the bandwidth to use. If \code{NULL}, the maximum bandwidth
#'   is applied automatically. Default is \code{NULL}.
#'
#' @return A matrix with two columns and as many rows as change points. Each row defines the start and end
#'   of the interval for a change point.
#'
#' @examples
#' change_points <- c(50, 100, 150)
#' n <- 200
#' bandwidth_fun(change_points, n, h = 10)
#'
#' @export
bandwidth_fun <- function(change_points, n, h = NULL) {
  if (!is.numeric(change_points) || length(change_points) == 0) stop("change_points must be a non-empty numeric vector.")
  if (!is.numeric(n) || n <= 0 || n != as.integer(n)) stop("'n' must be a positive integer.")
  if (!is.null(h) && (!is.numeric(h) || h <= 0)) stop("'h' must be a positive numeric value or NULL.")

  K <- length(change_points)
  tau <- c(0, change_points, n)

  if (!is.null(h) && h > min(floor(diff(tau) / 2))) {
    warning("'h' is too large. Setting h = NULL to apply the maximum bandwidth.")
    h <- NULL
  }

  if (is.null(h)) {
    cutoff <- ceiling((tau[-length(tau)] + tau[-1]) / 2)
    return(cbind(cutoff[-(K + 1)], cutoff[-1] - 1))
  }

  cbind(change_points - h, change_points + h - 1)
}

.trim_even_ncol <- function(X) {
  n <- ncol(X)
  if (n %% 2 != 0) {
    warning("Input matrix has an odd number of columns; the last column will be dropped.")
    n <- n - 1
    X <- X[, seq_len(n), drop = FALSE]
  }
  list(X = X, n = n)
}

.split_odd_even_cols <- function(X) {
  idx <- seq_len(ncol(X))
  index_O <- idx[idx %% 2 == 1]
  index_E <- idx[idx %% 2 == 0]
  list(
    index_O = index_O,
    index_E = index_E,
    O_df = X[, index_O, drop = FALSE],
    E_df = X[, index_E, drop = FALSE]
  )
}

.detect_mean_cpts <- function(x, k, method) {
  fit <- changepoint::cpt.mean(
    as.numeric(x),
    penalty = "None",
    method = method,
    Q = k,
    class = FALSE
  )
  fit[-length(fit)]
}

#' Robust Multivariate Order-Preserved Test for Change-Point Detection
#'
#' This function implements the R_MOPS method for detecting change points in multivariate data.
#' The method uses a knockoff thresholding approach to control the false discovery rate (FDR).
#'
#' @param X A numeric matrix of size \eqn{p \times n}, where \eqn{p} is the number of dimensions and \eqn{n} is the number of observations.
#' @param fdr A numeric value specifying the target false discovery rate. Must be in \eqn{(0, 1)}.
#' @param h An optional numeric value specifying the bandwidth for the intervals around change points. Default is \code{NULL}.
#' @param method A character string specifying the change-point detection method.
#'   Options are \code{'BinSeg'} and \code{'SegNeigh'}.
#'
#' @return A numeric vector of detected change points that pass the FDR threshold,
#'   reported on the original (pre-split) time index.
#'
#' @examples
#' # Simulate data
#' set.seed(123)
#' X <- matrix(rnorm(200), nrow = 2) # Two dimensions, 100 observations
#' result <- R_MOPS(X, fdr = 0.1, method = "BinSeg")
#' print(result)
#'
#' @export
R_MOPS <- function(X, fdr, h = NULL, method = c("BinSeg", "SegNeigh")) {
  method <- match.arg(method)
  if (!is.matrix(X)) stop("'X' must be a matrix.")
  if (!is.numeric(fdr) || fdr <= 0 || fdr >= 1) stop("'fdr' must be a numeric value in (0, 1).")
  if (!is.null(h) && (!is.numeric(h) || h <= 0)) stop("'h' must be a positive numeric value or NULL.")

  p <- nrow(X)
  trimmed <- .trim_even_ncol(X)
  split <- .split_odd_even_cols(trimmed$X)
  O <- split$O_df
  E <- split$E_df

  change_points_odd <- .detect_mean_cpts(O[1, , drop = FALSE], k = 7, method = method)
  K <- length(change_points_odd)
  if (K == 0) return(integer(0))

  change_points <- c(0, change_points_odd, ncol(O))
  W_c <- numeric(K)

  for (i in seq_len(K)) {
    idx_neg <- (change_points[i] + 1):change_points[i + 1]
    idx_pos <- (change_points[i + 1] + 1):change_points[i + 2]

    n_neg <- length(idx_neg)
    n_pos <- length(idx_pos)

    SE_neg <- matrix(rowMeans(E[, idx_neg, drop = FALSE]), ncol = 1)
    SO_neg <- matrix(rowMeans(O[, idx_neg, drop = FALSE]), ncol = 1)
    SE_pos <- matrix(rowMeans(E[, idx_pos, drop = FALSE]), ncol = 1)
    SO_pos <- matrix(rowMeans(O[, idx_pos, drop = FALSE]), ncol = 1)

    W_c[i] <- as.numeric(((n_neg * n_pos) / (n_neg + n_pos)) *
      t(SE_neg - SE_pos) %*% diag(p) %*% (SO_neg - SO_pos))
  }

  thre <- knockoff::knockoff.threshold(W_c, fdr = fdr)
  selected_odd <- change_points_odd[which(W_c >= thre)]
  2 * selected_odd - 1
}


#' Cross-Validation for Optimal Partition Selection in Segmentation (COPSS)
#'
#' This function implements the COPSS method for selecting the optimal number of change points
#' in multivariate data. It uses cross-validation by splitting the data into odd and even samples,
#' fitting candidate models, and computing the error matrix to select the model with the minimum error.
#'
#' @param X A numeric matrix of size \eqn{p \times n}, where \eqn{p} is the number of dimensions
#' and \eqn{n} is the number of observations.
#' @param model A numeric vector specifying the candidate numbers of change points to consider.
#' @param method A character string specifying the change-point detection method. Options are
#' \code{'BinSeg'} (Binary Segmentation) or \code{'SegNeigh'} (Segment Neighbourhood). Default is \code{'BinSeg'}.
#'
#' @return The optimal number of change points from the candidate models.
#'
#' @examples
#' # Simulate data
#' set.seed(123)
#' X <- matrix(rnorm(200), nrow = 2) # Two dimensions, 100 observations
#' model <- c(1, 2, 3)              # Candidate change-point models
#'
#' # Run COPSS
#' result <- COPSS(X, model = model, method = 'BinSeg')
#' print(result)
#'
#' @export
COPSS <- function(X, model, method = c('BinSeg', 'SegNeigh')) {
  method <- match.arg(method)
  if (!is.matrix(X)) stop("Input 'X' must be a matrix.")
  if (!is.numeric(model) || any(model <= 0)) stop("Input 'model' must be a numeric vector of positive integers.")

  trimmed <- .trim_even_ncol(X)
  X <- trimmed$X
  n <- trimmed$n
  split <- .split_odd_even_cols(X)
  index_O <- split$index_O
  index_E <- split$index_E
  O_df <- split$O_df
  E_df <- split$E_df

  K <- length(model)
  Err_matrix <- matrix(nrow = K, ncol = n)

  for (i in seq_along(model)) {
    k <- model[i]
    change_points <- .detect_mean_cpts(O_df[1, , drop = FALSE], k = k, method = method)
    mean_c <- estimate_mean(O_df, change_points)
    Err_matrix[i, index_E] <- apply(E_df - mean_c, 2, l2)

    change_points <- .detect_mean_cpts(E_df[1, , drop = FALSE], k = k, method = method)
    mean_c <- estimate_mean(E_df, change_points)
    Err_matrix[i, index_O] <- apply(O_df - mean_c, 2, l2)
  }

  model.min <- which.min(rowMeans(Err_matrix^2))
  model[model.min]
}
