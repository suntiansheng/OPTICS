#' Compute Bandwidth Intervals for Change Points
#'
#' This function calculates bandwidth intervals around change points. If the bandwidth `h` is not specified,
#' the maximum possible bandwidth is used. The intervals are adjusted to ensure they do not overlap excessively.
#'
#' @param change_points A numeric vector of change-point locations.
#' @param n The number of observations in the dataset.
#' @param h An optional numeric value specifying the bandwidth to use. If \code{NULL}, the maximum bandwidth
#'   is applied automatically. Default is \code{NULL}.
#'
#' @return A matrix with two columns and as many rows as change points. Each row defines the start and end
#'   of the interval for a change point.
#'
#' @examples
#' change_points <- c(50, 100, 150)
#' n <- 200
#' bandwidth_fun(change_points, n, h = 10)
#'
#' @export
bandwidth_fun <- function(change_points, n, h = NULL) {
  # Validate inputs
  if (!is.numeric(change_points) || length(change_points) == 0) stop("change_points must be a non-empty numeric vector.")
  if (!is.numeric(n) || n <= 0 || n != as.integer(n)) stop("'n' must be a positive integer.")
  if (!is.null(h) && (!is.numeric(h) || h <= 0)) stop("'h' must be a positive numeric value or NULL.")

  K <- length(change_points)
  tau <- c(0, change_points, n)

  # Check if bandwidth is too large
  if (!is.null(h) && h > min(floor(diff(tau) / 2))) {
    warning("'h' is too large. Setting h = NULL to apply the maximum bandwidth.")
    h <- NULL
  }

  # Compute intervals based on bandwidth
  if (is.null(h)) {
    # Maximum bandwidth
    cutoff <- sapply(1:(K + 1), function(t) ceiling((tau[t] + tau[t + 1]) / 2))
    interval_m <- matrix(ncol = 2, nrow = K)
    for (i in 1:K) {
      interval_m[i, 1] <- cutoff[i]
      interval_m[i, 2] <- cutoff[i + 1] - 1
    }
  } else {
    # Custom bandwidth
    interval_m <- matrix(ncol = 2, nrow = K)
    for (i in 1:K) {
      interval_m[i, 1] <- change_points[i] - h
      interval_m[i, 2] <- change_points[i] + h - 1
    }
  }

  return(interval_m)
}

#' Robust Multivariate Order-Preserved Test for Change-Point Detection
#'
#' This function implements the R_MOPS method for detecting change points in multivariate data.
#' The method uses a knockoff thresholding approach to control the false discovery rate (FDR).
#'
#' @param X A numeric matrix of size \eqn{p \times n}, where \eqn{p} is the number of dimensions and \eqn{n} is the number of observations.
#' @param fdr A numeric value specifying the target false discovery rate. Must be in \eqn{(0, 1)}.
#' @param h An optional numeric value specifying the bandwidth for the intervals around change points. Default is \code{NULL}.
#' @param method A character string specifying the change-point detection method. Options include \code{'BinSeg'}, \code{'SegNeigh'}, etc.
#'
#' @return A numeric vector of detected change points that pass the FDR threshold.
#'
#' @examples
#' # Simulate data
#' set.seed(123)
#' X <- matrix(rnorm(200), nrow = 2) # Two dimensions, 100 observations
#' result <- R_MOPS(X, fdr = 0.1, method = "BinSeg")
#' print(result)
#'
#' @export
R_MOPS <- function(X, fdr, h = NULL, method) {
  # Validate inputs
  if (!is.matrix(X)) stop("'X' must be a matrix.")
  if (!is.numeric(fdr) || fdr <= 0 || fdr >= 1) stop("'fdr' must be a numeric value in (0, 1).")
  if (!is.null(h) && (!is.numeric(h) || h <= 0)) stop("'h' must be a positive numeric value or NULL.")
  if (!is.character(method) || length(method) != 1) stop("'method' must be a single character string.")

  # Extract dimensions
  n <- dim(X)[2]
  p <- dim(X)[1]

  # Ensure even number of observations
  if (n %% 2 != 0) {
    warning("The number of observations is odd; the last column will be dropped.")
    n <- n - 1
    X <- X[, 1:n]
  }

  # Data splitting
  tt <- 1:n
  index_O <- tt[tt %% 2 == 1] # Odd indices
  index_E <- tt[tt %% 2 == 0] # Even indices
  O <- X[, index_O, drop = FALSE] # Odd sample
  E <- X[, index_E, drop = FALSE] # Even sample

  # Initial change-point estimation
  res_fit <- changepoint::cpt.mean(as.vector(O[1, ]), penalty = 'None', method = method, Q = 7)
  change_points <- changepoint::cpts(res_fit)
  K <- length(change_points)

  # Adjust change points for even samples
  n_O <- length(index_O)
  change_points <- c(0, change_points, n)
  change_points <- floor(change_points / 2) # Scale to even indices
  W_c <- numeric(K) # Initialize test statistics

  # Compute test statistics for each interval
  for (i in 2:(K + 1)) {
    idx_neg <- (change_points[i - 1] + 1):change_points[i] # Negative interval
    idx_pos <- (change_points[i] + 1):change_points[i + 1] # Positive interval

    n_neg <- length(idx_neg)
    n_pos <- length(idx_pos)

    SE_neg <- matrix(rowMeans(E[, idx_neg, drop = FALSE]), ncol = 1)
    SO_neg <- matrix(rowMeans(O[, idx_neg, drop = FALSE]), ncol = 1)
    SE_pos <- matrix(rowMeans(E[, idx_pos, drop = FALSE]), ncol = 1)
    SO_pos <- matrix(rowMeans(O[, idx_pos, drop = FALSE]), ncol = 1)

    Omega_inv <- diag(p) # Identity covariance matrix
    W_c[i - 1] <- as.numeric(((n_neg * n_pos) / (n_neg + n_pos)) *
                               t(SE_neg - SE_pos) %*% Omega_inv %*% (SO_neg - SO_pos))
  }

  # Apply knockoff thresholding to control FDR
  thre <- knockoff::knockoff.threshold(W_c, fdr = fdr)

  # Return detected change points
  return(change_points[which(W_c >= thre)])
}


#' Cross-Validation for Optimal Partition Selection in Segmentation (COPSS)
#'
#' This function implements the COPSS method for selecting the optimal number of change points
#' in multivariate data. It uses cross-validation by splitting the data into odd and even samples,
#' fitting candidate models, and computing the error matrix to select the model with the minimum error.
#'
#' @param X A numeric matrix of size \eqn{p \times n}, where \eqn{p} is the number of dimensions
#' and \eqn{n} is the number of observations.
#' @param model A numeric vector specifying the candidate numbers of change points to consider.
#' @param method A character string specifying the change-point detection method. Options are
#' \code{'BinSeg'} (Binary Segmentation) or \code{'SegNeigh'} (Segment Neighbourhood). Default is \code{'BinSeg'}.
#'
#' @return The optimal number of change points from the candidate models.
#'
#' @examples
#' # Simulate data
#' set.seed(123)
#' X <- matrix(rnorm(200), nrow = 2) # Two dimensions, 100 observations
#' model <- c(1, 2, 3)              # Candidate change-point models
#'
#' # Run COPSS
#' result <- COPSS(X, model = model, method = 'BinSeg')
#' print(result)
#'
#' @export
COPSS <- function(X, model, method = c('BinSeg', 'SegNeigh')) {
  # Validate inputs
  if (!is.matrix(X)) stop("Input 'X' must be a matrix.")
  if (!is.numeric(model) || any(model <= 0)) stop("Input 'model' must be a numeric vector of positive integers.")
  if (!method %in% c('BinSeg', 'SegNeigh')) stop("Input 'method' must be either 'BinSeg' or 'SegNeigh'.")

  # Extract dimensions
  p <- dim(X)[1] # Number of dimensions
  n <- dim(X)[2] # Number of observations
  K <- length(model) # Number of candidate models

  # Ensure even number of observations
  if (n %% 2 != 0) {
    warning("Input matrix has an odd number of columns; the last column will be dropped.")
    n <- n - 1
    X <- X[, 1:n]
  }

  # Data splitting: Split into odd and even indices
  tt <- 1:n
  index_O <- tt[tt %% 2 == 1] # Odd indices
  index_E <- tt[tt %% 2 == 0] # Even indices
  O_df <- X[, index_O, drop = FALSE] # Odd sample
  E_df <- X[, index_E, drop = FALSE] # Even sample

  # Initialize the error matrix
  Err_matrix <- matrix(nrow = K, ncol = n)

  # Compute the error matrix for each candidate model
  for (i in seq_along(model)) {
    k <- model[i]

    # Fit change-point model on odd samples
    res_fit <- changepoint::cpt.mean(as.numeric(O_df[1, ]), penalty = 'None', method = method, Q = k, class = FALSE)
    change_points <- res_fit[-length(res_fit)] # Exclude the last element (segment count)
    mean_c <- estimate_mean(O_df, change_points)
    Err_matrix[i, index_E] <- apply(E_df - mean_c, 2, l2)

    # Fit change-point model on even samples
    res_fit <- changepoint::cpt.mean(as.numeric(E_df[1, ]), penalty = 'None', method = method, Q = k, class = FALSE)
    change_points <- res_fit[-length(res_fit)]
    mean_c <- estimate_mean(E_df, change_points)
    Err_matrix[i, index_O] <- apply(O_df - mean_c, 2, l2)
  }

  # Select the model with the minimum error
  model.min <- which.min(rowMeans(Err_matrix^2))
  return(model[model.min])
}
