#' Multiple-Splitting OPTICS for Finite-Sample Stability
#'
#' Applies OPTICS over multiple order-preserving splits and combines split-wise
#' p-values using the Cauchy combination rule.
#'
#' @param X A numeric matrix of size \eqn{p \times n}, where columns represent
#'   time/order.
#' @param model A numeric vector of candidate numbers of change-points.
#' @param engine A character string specifying the split-wise OPTICS engine:
#'   \code{"mean"} (univariate base detector on first row) or \code{"dmean"}
#'   (multivariate detector).
#' @param method A character string passed to split-wise detectors.
#'   \code{"BinSeg"} or \code{"SegNeigh"}.
#' @param alpha Significance level for forming the confidence set.
#' @param B Number of bootstrap iterations for split-wise OPTICS tests.
#' @param delta Minimum segment length used by the \code{"dmean"} detector.
#' @param L Number of order-preserving splits.
#' @param weights Optional nonnegative weights for Cauchy aggregation. If
#'   \code{NULL}, uniform weights are used.
#' @param trim_incomplete Logical; if \code{TRUE}, trims trailing columns so the
#'   final length is divisible by \code{L}. If \code{FALSE}, requires exact
#'   divisibility.
#'
#' @return A list containing:
#' \describe{
#'   \item{\code{A_MS}}{Multiple-splitting OPTICS confidence set.}
#'   \item{\code{pvals_split}}{Matrix of split-wise p-values (\eqn{|M| \times L}).}
#'   \item{\code{pvals_combined}}{Cauchy-combined p-values indexed by \code{model}.}
#'   \item{\code{weights}}{Normalized weights used in aggregation.}
#'   \item{\code{model.min_split}}{Split-wise empirical risk minimizers.}
#' }
#'
#' @examples
#' set.seed(123)
#' X <- matrix(rnorm(8 * 240), nrow = 8)
#' model <- c(1, 2, 3, 4)
#' out <- OPTICS.ms(X, model, engine = "dmean", method = "BinSeg", B = 50, L = 3)
#' out$A_MS
#'
#' @export
OPTICS.ms <- function(X, model, engine = c("dmean", "mean"),
                      method = c("BinSeg", "SegNeigh"),
                      alpha = 0.1, B = 200, delta = 20,
                      L = 2, weights = NULL, trim_incomplete = FALSE) {
  engine <- match.arg(engine)
  method <- match.arg(method)
  .optics_validate_X_model_alpha_B(X, model, alpha, B)
  if (!is.numeric(delta) || delta <= 0) stop("Input 'delta' must be a positive numeric value.")
  if (!is.numeric(L) || L < 2 || L != as.integer(L)) stop("Input 'L' must be an integer >= 2.")
  if (!is.logical(trim_incomplete) || length(trim_incomplete) != 1) stop("Input 'trim_incomplete' must be TRUE or FALSE.")

  n <- ncol(X)
  rem <- n %% L
  if (rem != 0) {
    if (!trim_incomplete) {
      stop("ncol(X) must be divisible by L when trim_incomplete = FALSE.")
    }
    n_new <- n - rem
    warning("ncol(X) is not divisible by L; trailing columns are dropped.")
    X <- X[, seq_len(n_new), drop = FALSE]
    n <- n_new
  }

  if (is.null(weights)) {
    weights <- rep(1 / L, L)
  } else {
    weights <- as.numeric(weights)
    if (length(weights) != L) stop("weights must have length L.")
    if (any(weights < 0)) stop("weights must be nonnegative.")
    if (sum(weights) <= 0) stop("weights must sum to a positive value.")
    weights <- weights / sum(weights)
  }

  model <- as.integer(model)
  K <- length(model)
  pvals_split <- matrix(NA_real_, nrow = K, ncol = L, dimnames = list(as.character(model), paste0("split_", seq_len(L))))
  model.min_split <- integer(L)

  for (r in seq_len(L)) {
    idx_r <- seq(from = r, to = n, by = L)
    X_r <- X[, idx_r, drop = FALSE]
    split <- .optics_prepare_odd_even_split(X_r)
    n_r <- split$n
    index_O <- split$index_O
    index_E <- split$index_E
    O_df <- split$O_df
    E_df <- split$E_df

    Err_matrix <- matrix(nrow = K, ncol = n_r)
    for (i in seq_len(K)) {
      k <- model[i]

      if (engine == "mean") {
        fit_o <- changepoint::cpt.mean(as.numeric(O_df[1, , drop = FALSE]), penalty = "None", method = method, Q = k, class = FALSE)
        cp_o <- fit_o[-length(fit_o)]
        mean_o <- estimate_mean(O_df, cp_o)
        Err_matrix[i, index_E] <- apply(E_df - mean_o, 2, l2)

        fit_e <- changepoint::cpt.mean(as.numeric(E_df[1, , drop = FALSE]), penalty = "None", method = method, Q = k, class = FALSE)
        cp_e <- fit_e[-length(fit_e)]
        mean_e <- estimate_mean(E_df, cp_e)
        Err_matrix[i, index_O] <- apply(O_df - mean_e, 2, l2)
      } else {
        cp_o <- dmean.detection.fun(O_df, num = k, method = method, delta = delta)
        mean_o <- estimate_mean(O_df, cp_o)
        Err_matrix[i, index_E] <- apply(E_df - mean_o, 2, l2)

        cp_e <- dmean.detection.fun(E_df, num = k, method = method, delta = delta)
        mean_e <- estimate_mean(E_df, cp_e)
        Err_matrix[i, index_O] <- apply(O_df - mean_e, 2, l2)
      }
    }

    pvals_split[, r] <- .optics_bootstrap_pvals(Err_matrix = Err_matrix, B = B)
    model.min_split[r] <- model[which.min(rowMeans(Err_matrix^2))]
  }

  pvals_combined <- apply(pvals_split, 1, .ms_cauchy_combine, weights = weights)
  names(pvals_combined) <- as.character(model)
  A_MS <- model[pvals_combined > alpha]

  list(
    A_MS = A_MS,
    pvals_split = pvals_split,
    pvals_combined = pvals_combined,
    weights = weights,
    model.min_split = model.min_split
  )
}

.ms_cauchy_combine <- function(pvals, weights) {
  pvals <- as.numeric(pvals)
  if (any(is.na(pvals))) stop("pvals contains NA.")
  eps <- 1e-15
  pvals <- pmin(pmax(pvals, eps), 1 - eps)
  t_stat <- sum(weights * tan((0.5 - pvals) * pi))
  p_comb <- 0.5 - atan(t_stat) / pi
  min(max(p_comb, 0), 1)
}
