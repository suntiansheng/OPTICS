test_that("Bootstrap_fun handles zero-variance residual rows", {
  Res_Error <- matrix(1, nrow = 3, ncol = 20)
  p <- OPTICS:::Bootstrap_fun(Res_Error, B = 50)
  expect_true(is.numeric(p))
  expect_equal(length(p), 1L)
  expect_gte(p, 0)
  expect_lte(p, 1)
})

test_that("CCT returns valid p-values", {
  p <- OPTICS:::CCT(c(0.2, 0.4, 0.8))
  expect_true(is.numeric(p))
  expect_equal(length(p), 1L)
  expect_gte(p, 0)
  expect_lte(p, 1)
})
