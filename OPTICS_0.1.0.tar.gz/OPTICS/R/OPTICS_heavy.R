#' Heavy-Tail Mean Change Detection using OPTICS
#'
#' This function performs mean change-point detection for heavy-tailed data using the OPTICS framework.
#' The detection leverages the Huber loss function for robust error calculation and supports
#' segmentation methods such as Binary Segmentation ('BinSeg') or Segment Neighborhood ('SegNeigh').
#'
#' @param X A numeric matrix of size \eqn{p \times n}, where \eqn{p} is the number of dimensions
#'   and \eqn{n} is the number of observations.
#' @param model A numeric vector specifying the candidate numbers of change points to consider.
#' @param method A character string specifying the segmentation method to use. Must be either
#'   \code{'BinSeg'} or \code{'SegNeigh'}.
#' @param alpha A numeric value specifying the confidence level for model selection. Must be in
#'   the range \eqn{(0, 1)}. Default is \code{0.1}.
#' @param B A positive integer specifying the number of bootstrap iterations. Default is \code{200}.
#'
#' @return A list containing:
#' \describe{
#'   \item{\code{A}}{A vector of models that pass the confidence level threshold.}
#'   \item{\code{model.min}}{The best model based on the minimum error.}
#' }
#'
#' @examples
#' # Simulate data
#' set.seed(123)
#' X <- matrix(rnorm(200), nrow = 5) # 5 dimensions, 40 observations
#' model <- c(1, 2, 3)              # Candidate change-point models
#'
#' # Run OPTICS.heavy_tail
#' result <- OPTICS.heavy_tail(X, model = model, method = "BinSeg", alpha = 0.1, B = 200)
#' print(result)
#'
#' @export
OPTICS.heavy_tail <- function(X, model, method = c('BinSeg', 'SegNeigh'), alpha = 0.1, B = 200) {
  # Match the method argument
  method <- match.arg(method)

  # Input validation
  if (!is.matrix(X)) stop("Input 'X' must be a matrix.")
  if (!is.numeric(model) || any(model <= 0)) stop("Input 'model' must be a numeric vector of positive integers.")
  if (!method %in% c('BinSeg', 'SegNeigh')) stop("Input 'method' must be either 'BinSeg' or 'SegNeigh'.")
  if (!is.numeric(alpha) || alpha <= 0 || alpha >= 1) stop("Input 'alpha' must be a numeric value in (0, 1).")
  if (!is.numeric(B) || B <= 0 || B != as.integer(B)) stop("Input 'B' must be a positive integer.")

  # Extract dimensions
  p <- dim(X)[1]
  n <- dim(X)[2]

  # Ensure even number of columns
  if (n %% 2 != 0) {
    warning("Input matrix has an odd number of columns; the last column will be dropped.")
    n <- n - 1
    X <- X[, 1:n, drop = FALSE]
  }

  # Data splitting
  tt <- 1:n
  index_O <- tt[tt %% 2 == 1] # Odd indices
  index_E <- tt[tt %% 2 == 0] # Even indices
  O_df <- X[, index_O, drop = FALSE] # Odd sample
  E_df <- X[, index_E, drop = FALSE] # Even sample

  # Initialize error matrix
  K <- length(model)
  Err_matrix <- matrix(nrow = K, ncol = n)

  # Compute error matrix
  for (i in seq_along(model)) {
    k <- model[i]

    # Fit change-point model on odd samples
    res_fit <- changepoint::cpt.mean(
      as.numeric(O_df[1, ]),
      penalty = 'None',
      method = method,
      Q = k,
      class = FALSE
    )
    change_points <- res_fit[-length(res_fit)]
    mean_c <- estimate_mean(O_df, change_points)
    Err_matrix[i, index_E] <- apply(E_df - mean_c, 2, Huber_loss, kappa = 1.5)

    # Fit change-point model on even samples
    res_fit <- changepoint::cpt.mean(
      as.numeric(E_df[1, ]),
      penalty = 'None',
      method = method,
      Q = k,
      class = FALSE
    )
    change_points <- res_fit[-length(res_fit)]
    mean_c <- estimate_mean(E_df, change_points)
    Err_matrix[i, index_O] <- apply(O_df - mean_c, 2, Huber_loss, kappa = 1.5)
  }

  # Validation
  p_c <- numeric(K)
  for (k in seq_along(model)) {
    Res_Error <- matrix(nrow = K - 1, ncol = n)
    res_set <- setdiff(seq_along(model), k)
    for (i in seq_along(res_set)) {
      Res_Error[i, ] <- Err_matrix[k, ] - Err_matrix[res_set[i], ]
    }
    p_c[k] <- Bootstrap_fun(Res_Error = Res_Error, B = B)
  }

  # Select the model with the minimum error
  model.min <- which.min(rowMeans(Err_matrix^2))
  return(list(A = model[p_c > alpha], model.min = model[model.min]))
}

#' Huber Loss Function
#'
#' Computes the Huber loss for robust error calculation.
#'
#' @param x A numeric vector of residuals.
#' @param kappa A numeric value specifying the threshold for the quadratic-linear transition. Default is \code{1.5}.
#' @return The Huber loss value.
Huber_loss <- function(x, kappa = 1.5) {
  if (!is.numeric(x)) stop("Input 'x' must be numeric.")
  if (!is.numeric(kappa) || kappa <= 0) stop("Input 'kappa' must be a positive numeric value.")

  # Calculate Huber loss
  loss <- ifelse(abs(x) <= kappa, x^2, 2 * kappa * abs(x) - kappa^2)
  return(sum(loss))
}
